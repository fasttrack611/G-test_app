// hello.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils/utils.h"

void print_usage(const char *prog_name) {
    printf("Usage: %s [--help | --verbose]\n", prog_name);
}

int main(int argc, char *argv[]) {
    printf("\n Welcome to W4 Linux with Buck2!\n");

    if (argc > 1) {
        if (strcmp(argv[1], "--help") == 0) {
            print_usage(argv[0]);
            return 0;
        } else if (strcmp(argv[1], "--verbose") == 0) {
            printf("[INFO] Verbose mode enabled.\n");
        } else {
            fprintf(stderr, "[ERROR] Unknown option: %s\n", argv[1]);
            print_usage(argv[0]);
            return 1;
        }
    }

    if (!print_utility_message()) {
        fprintf(stderr, "[ERROR] Failed to print utility message.\n");
        return 1;
    }

    return 0;
}
