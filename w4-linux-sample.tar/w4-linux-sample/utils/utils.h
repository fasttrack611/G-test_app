// utils.h
#ifndef UTILS_H
#define UTILS_H

int print_utility_message();

#endif

