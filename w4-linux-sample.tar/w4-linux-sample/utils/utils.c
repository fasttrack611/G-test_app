// utils.c
#include <stdio.h>
#include <time.h>
#include "utils.h"

#if 0 
int print_utility_message() {
    printf("This is a utility message.\n");
    return 1; // or 0 for failure
}
#endif 

int print_utility_message() {
    // Get current time
    time_t now = time(NULL);
    struct tm *tinfo = localtime(&now);

    if (!tinfo) {
        fprintf(stderr, "[ERROR] Failed to retrieve local time.\n");
        return 0;
    }

    // Print timestamped utility message
    char timestamp[32];
    strftime(timestamp, sizeof(timestamp), "%Y-%m-%d %H:%M:%S", tinfo);

    printf("\n[INFO] [%s] Utility function activated...\n", timestamp);
    printf("\n         This message comes from the utility module.\n");

    return 1;
}

